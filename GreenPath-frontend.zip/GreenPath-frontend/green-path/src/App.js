import './App.css';
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import HomePage from './pages/homePage';
import News from './pages/news';
import Blogs from './pages/blogs';
import Customer from './pages/customer';
import Announcements from './pages/showBlogs';
import ContactUs from './pages/contactus';
import AboutUs from './pages/aboutus';

function App() {

  return (
    <Router>
      <Routes>
        <Route path='/' element={<HomePage />} />
        <Route path='/news' element={<News />} />
        <Route path='/blogs' element={<Blogs />} />
        <Route path='/customer' element={<Customer />} />
        <Route path='/announcements' element={<Announcements />} />
        <Route path='/contactus' element={<ContactUs />} />
        <Route path='/aboutus' element={<AboutUs />} />
      </Routes>
    </Router>
  );

}

export default App;



