import "../css/product.css";
import { useState } from "react";
import { Paper, Button } from '@mui/material';
import React, { useContext, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";

export default function Customer({ handleSelectChange, handleMinPriceChange, handleMaxPriceChange, fetchItemLink, item1 }) {

    const [title, setTitle] = useState("");
    const [minprice, setMinprice] = useState("");
    const [maxprice, setMaxprice] = useState("");
    const [item, setItem] = useState("");
    const [description, setDescription] = useState("");
    const [date, setDate] = useState(new Date());
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Create a new product object
        const product = {
            type: item,
            minPrice: minprice,
            maxPrice: maxprice
        };

        try {
            const res = await fetch(`http://localhost:5000/products`, {
                method: "POST",
                headers: {
                    "content-type": "application/json",
                },
                body: JSON.stringify(product),
            });

            const data = await res.json();

            if (!res.ok) {
                throw new Error(data.message);
            }
            // If the request is successful, you can handle the response here
            console.log(data);
        }
        catch (err) {
            // Handle errors
            if (err.message) {
                setError(err.message);
            } else {
                setError("Something went wrong. Please try again later.");
            }
        }
    }

    return (
        <div style={{backgroundColor:"rgb(223, 248, 239)", height: "45.5rem"}}>
            <h2 className="top1">Help save the environment</h2>
            <h1 className="top2">Select your eco-friendly product:</h1>

            <div class="main1">

                <Paper elevation={4} style={{ width: "40%", marginRight: "1.5rem", height: "53%" }} >
                    <div class="selection">
                        <form onSubmit={handleSubmit}>
                            <div class="product">
                                <label class="items" for="items">Product: </label>
                                <select class="itemSelect" onChange={(e) => setItem(e.target.value)}>
                                    <option value="Laundry">Laundry</option>
                                    <option value="Kitchen">Kitchen</option>
                                    <option value="Skin">Personal care</option>
                                    <option value="Cleaning">Cleaning</option>
                                    {/* <!-- Add more options as needed --> */}
                                </select>

                            </div>

                            <div class="mp">
                                <label for="minPrice" >Minimum Price:</label>
                                <input type="number" class="price" id="minPrice" name="minPrice" onChange={(e) => setMinprice(e.target.value)} />
                            </div>
                            <div class="Mp">
                                <label for="maxPrice">Maximum Price:</label>
                                <input type="number" class="price" id="maxPrice" name="maxPrice" onChange={(e) => setMaxprice(e.target.value)} />
                            </div>

                            <div class="fetch">
                                <Button type="submit" variant="contained">Fetch Item</Button>
                                {/* <button onChange={fetchItemLink}>Fetch Item Link</button> */}
                            </div>
                        </form>

                    </div>
                </Paper>
            </div>


        </div>
    )
}
